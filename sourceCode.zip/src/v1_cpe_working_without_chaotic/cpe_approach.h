#ifndef CPE_APPROACH_H
#define CPE_APPROACH_H

#include <opencv2/opencv.hpp>
#include <stdint.h>
void cpe_approach(cv::Mat* srcImg, int32_t imgKey, int32_t msgKey);
 
#endif